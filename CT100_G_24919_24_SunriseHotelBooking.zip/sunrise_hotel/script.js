const roomCapacities = {
    "Single": 1,
    "Double": 2,
    "Family": 4
};

const roomRates = {
    "Single": 3500,
    "Double": 5000,
    "Family": 7500
};

document.addEventListener("DOMContentLoaded", function () {
    const roomSelect = document.getElementById("roomType");
    const guestsInput = document.getElementById("guests");
    const nightsInput = document.getElementById("nights");
    const airportTransferCheck = document.getElementById("airportTransfer");
    const laundryCheck = document.getElementById("laundryService");
    const breakfastRadios = document.querySelectorAll("input[name='breakfast']");
    const lateCheckout = document.getElementById("latecheckout");

    roomSelect.addEventListener("change", function () {
        checkRoomCapacity();
        calculateBill();
    });

    guestsInput.addEventListener("input", calculateBill);
    nightsInput.addEventListener("input", calculateBill);
    airportTransferCheck.addEventListener("change", calculateBill);
    laundryCheck.addEventListener("change", calculateBill);
    lateCheckout.addEventListener("change", calculateBill);
    breakfastRadios.forEach(radio => radio.addEventListener("change", calculateBill));

    calculateBill();
});

function checkRoomCapacity() {
    const roomType = document.getElementById("roomType").value;
    const capacityInfo = document.getElementById("capacityInfo");
    const capacityWarning = document.getElementById("capacityWarning");
    const guestsInput = document.getElementById("guests");

    if (roomType && roomCapacities[roomType]) {
        const maxGuests = roomCapacities[roomType];
        capacityInfo.textContent = `Maximum capacity for ${roomType} room is ${maxGuests} guest(s).`;
        
        if (parseInt(guestsInput.value) > maxGuests) {
            capacityWarning.textContent = "Warning: Number of guests exceeds the maximum room capacity!";
        } else {
            capacityWarning.textContent = "";
        }
    } else {
        capacityInfo.textContent = "";
        capacityWarning.textContent = "";
    }
}

function calculateBill() {
    const roomType = document.getElementById("roomType").value;
    const nights = parseInt(document.getElementById("nights").value) || 0;
    const guests = parseInt(document.getElementById("guests").value) || 0;
    const breakfastSelected = document.querySelector("input[name='breakfast']:checked").value === "Yes";
    const airportTransferSelected = document.getElementById("airportTransfer").checked;
    const laundrySelected = document.getElementById("laundryService").checked;
    const lateCheckout = document.getElementById("latecheckout").checked;

    let roomCost = 0;
    if (roomRates[roomType]) {
        roomCost = roomRates[roomType] * nights;
    }

    let breakfastCost = 0;
    if (breakfastSelected) {
        breakfastCost = 700 * guests * nights;
    }

    let transferCost = airportTransferSelected ? 2000 : 0;
    let laundryCost = laundrySelected ? 1000 : 0;
    let lateCheckoutCost = lateCheckout ? 2000 : 0;
    let total = roomCost + breakfastCost + transferCost + laundryCost + lateCheckoutCost;

    document.getElementById("displayTotal").textContent = "KSh " + total.toLocaleString();
    document.getElementById("calculatedTotal").value = total;

    checkRoomCapacity();
}

function validateBooking() {
    let isValid = true;

    const fullName = document.getElementById("fullName").value.trim();
    const nameError = document.getElementById("nameError");
    if (fullName === "") {
        nameError.textContent = "Customer name cannot be empty.";
        isValid = false;
    } else {
        nameError.textContent = "";
    }

    const email = document.getElementById("email").value.trim();
    const emailError = document.getElementById("emailError");
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        emailError.textContent = "Please enter a valid email address.";
        isValid = false;
    } else {
        emailError.textContent = "";
    }

    const phone = document.getElementById("phone").value.trim();
    const phoneError = document.getElementById("phoneError");
    const phoneRegex = /^\d{10}$/;
    if (!phoneRegex.test(phone)) {
        phoneError.textContent = "Phone number must contain exactly 10 digits.";
        isValid = false;
    } else {
        phoneError.textContent = "";
    }

    const nights = parseInt(document.getElementById("nights").value);
    const nightsError = document.getElementById("nightsError");
    if (isNaN(nights) || nights < 1 || nights > 14) {
        nightsError.textContent = "Number of nights must be between 1 and 14.";
        isValid = false;
    } else {
        nightsError.textContent = "";
    }

    const guests = parseInt(document.getElementById("guests").value);
    const guestsError = document.getElementById("guestsError");
    const roomType = document.getElementById("roomType").value;
    if (isNaN(guests) || guests <= 0) {
        guestsError.textContent = "Number of guests must be greater than zero.";
        isValid = false;
    } else if (roomType && guests > roomCapacities[roomType]) {
        guestsError.textContent = `Guests exceed room capacity (${roomCapacities[roomType]}).`;
        isValid = false;
    } else {
        guestsError.textContent = "";
    }

    const roomError = document.getElementById("roomError");
    if (roomType === "") {
        roomError.textContent = "Please select a room type.";
        isValid = false;
    } else {
        roomError.textContent = "";
    }

    return isValid;
}