<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullName = trim($_POST['fullName'] ?? '');
    $idNumber = trim($_POST['idNumber'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $checkInDate = $_POST['checkInDate'] ?? '';
    $nights = intval($_POST['nights'] ?? 1);
    $roomType = $_POST['roomType'] ?? '';
    $guests = intval($_POST['guests'] ?? 1);
    $breakfast = $_POST['breakfast'] ?? 'No';
    $airportTransfer = isset($_POST['airportTransfer']) ? 'Yes' : 'No';
    $laundryService = isset($_POST['laundryService']) ? 'Yes' : 'No';
    $lateCheckout = isset($_POST['latecheckout']) ? 'Yes' : 'No';

    $errors = [];
    if (empty($fullName)) $errors[] = "Customer name is required.";
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Invalid email format.";
    if (!preg_match('/^\d{10}$/', $phone)) $errors[] = "Phone number must be 10 digits.";
    if ($nights < 1 || $nights > 14) $errors[] = "Number of nights must be between 1 and 14.";
    if ($guests < 1) $errors[] = "Number of guests must be greater than zero.";
    
    $validRooms = ['Single' => 3500, 'Double' => 5000, 'Family' => 7500];
    if (!array_key_exists($roomType, $validRooms)) {
        $errors[] = "Invalid room type selected.";
    }

    if (!empty($errors)) {
        echo "<h2>Submission Error</h2><ul>";
        foreach ($errors as $error) {
            echo "<li>" . htmlspecialchars($error) . "</li>";
        }
        echo "</ul><p><a href='booking.html'>Go Back</a></p>";
        exit;
    }

    $roomRate = $validRooms[$roomType];
    $roomCost = $roomRate * $nights;
    
    $breakfastCost = ($breakfast === 'Yes') ? (700 * $guests * $nights) : 0;
    $transferCost = ($airportTransfer === 'Yes') ? 2000 : 0;
    $laundryCost = ($laundryService === 'Yes') ? 1000 : 0;
    $lateCheckoutCost = ($lateCheckout === 'Yes') ? 2000 : 0;

    $serverTotal = $roomCost + $breakfastCost + $transferCost + $laundryCost + $lateCheckoutCost;

} else {
    header("Location: booking.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sunrise Hotel - Booking Confirmation</title>
    <link rel="stylesheet" href="booking.css">
</head>
<body>
    <header>
        <div class="container">
            <h1>Sunrise Hotel</h1>
            <nav>
                <a href="index.html">Home</a>
                <a href="booking.html">Book Room</a>
            </nav>
        </div>
    </header>

    <main class="container">
        <div class="confirmation-card">
            <h2>BOOKING CONFIRMED</h2>
            <ul class="confirmation-details">
                <li><strong>Customer:</strong> <?php echo htmlspecialchars($fullName); ?></li>
                <li><strong>Room:</strong> <?php echo htmlspecialchars($roomType); ?> Room</li>
                <li><strong>Guests:</strong> <?php echo $guests; ?></li>
                <li><strong>Number of Nights:</strong> <?php echo $nights; ?></li>
                <li><strong>Breakfast:</strong> <?php echo $breakfast; ?></li>
                <li><strong>Airport Transfer:</strong> <?php echo $airportTransfer; ?></li>
                <li><strong>Laundry Service:</strong> <?php echo $laundryService; ?></li>
                <li><strong>Late Checkout:</strong> <?php echo $lateCheckout; ?></li>
                <li><strong>Check-in Date:</strong> <?php echo htmlspecialchars($checkInDate); ?></li>
            </ul>
            <h3>TOTAL AMOUNT: KSh <?php echo number_format($serverTotal); ?></h3>
            <br>
            <p><em>Thank you for choosing Sunrise Hotel.</em></p>
            <br>
            <a href="booking.html" class="btn">Make Another Booking</a>
        </div>
    </main>

    <footer>
        <p>&copy; 2026 Sunrise Hotel. All rights reserved.</p>
    </footer>
</body>
</html>